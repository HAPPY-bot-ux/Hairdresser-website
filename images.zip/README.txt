Nelz Hair Dresser - 7 page Tailwind site
Open index.html in a browser. Images are hotlinked from Unsplash. Replace contact details and maps embed for production.